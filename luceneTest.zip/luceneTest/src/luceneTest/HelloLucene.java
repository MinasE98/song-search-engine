package luceneTest;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.ByteBuffersDirectory;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class HelloLucene implements ActionListener {
    private static List<String> searchHistory = new ArrayList<>();
	private static JTextArea searchHistoryBox = new JTextArea(10, 30);
    private static StandardAnalyzer analyzer = new StandardAnalyzer();
    private static Directory index;
    private static JTextField searchBox;
    private static JComboBox<String> fieldBox;
    private static JTextArea resultBox;
    private static IndexSearcher searcher;
    private static Query lastQuery;
    private static int currentPage = 0;

    public static void main(String[] args) throws IOException, ParseException, CsvException {
        // create the index
        index = createIndex(analyzer);
        IndexReader reader = DirectoryReader.open(index);
        searcher = new IndexSearcher(reader);

        // create GUI
        JFrame frame = new JFrame("Lucene Search");
        JPanel panel = new JPanel(new BorderLayout());
        searchBox = new JTextField();
        String[] fields = {"artist", "song", "link", "text"};
        fieldBox = new JComboBox<>(fields);
        JButton searchButton = new JButton("Search");
        JButton nextButton = new JButton("Next Page");
        resultBox = new JTextArea(20, 80);
        resultBox.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultBox);
        JPanel searchPanel = new JPanel(new BorderLayout());
        JScrollPane searchHistoryScrollPane = new JScrollPane(searchHistoryBox);
        panel.add(searchHistoryScrollPane, BorderLayout.WEST);
        searchPanel.add(searchBox, BorderLayout.CENTER);
        searchPanel.add(fieldBox, BorderLayout.EAST);
        panel.add(searchPanel, BorderLayout.NORTH);
        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.add(searchButton, BorderLayout.WEST);
        buttonPanel.add(nextButton, BorderLayout.EAST);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // add action listener to search button
        searchButton.addActionListener(new HelloLucene());

        // add action listener to next button
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentPage++;
                try {
                    TopDocs docs = searcher.search(lastQuery, (currentPage + 1) * 10);
                    ScoreDoc[] hits = docs.scoreDocs;

                    int start = currentPage * 10;
                    int end = Math.min((currentPage + 1) * 10, hits.length);

                    resultBox.setText("");
                    resultBox.append("Showing results " + (start + 1) + " to " + end + " out of " + hits.length + " total results.\n");

                    for (int i = start; i < end; ++i) {
                        int docId = hits[i].doc;
                        Document d = searcher.doc(docId);
                        resultBox.append(d.get("artist") + "\t" + d.get("song") + "\t" + d.get("link") + "\t" + d.get("text") + "\n");
                    }

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });


    }

    private static Directory createIndex(StandardAnalyzer analyzer) throws IOException, CsvException {
        Directory index = new ByteBuffersDirectory();
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter w = new IndexWriter(index, config);

        // Read CSV file and index the data
        try (CSVReader reader = new CSVReader(new FileReader("spotify_millsongdata.csv"))) {
            String[] header = reader.readNext(); // Skip header row
            String[] line;
            while ((line = reader.readNext()) != null) {
                String artist = line[0];
                String song = line[1];
                String link = line[2];
                String text = line[3];
                addDoc(w, artist, song, link, text);
            }
        }

        w.close();
        return index;
    }

    private static void addDoc(IndexWriter w, String artist, String song, String link, String text) throws IOException {
        Document doc = new Document();
        doc.add(new TextField("artist", artist, Field.Store.YES));
        doc.add(new TextField("song", song, Field.Store.YES));
        doc.add(new TextField("link", link, Field.Store.YES));
        doc.add(new TextField("text", text, Field.Store.YES));
        w.addDocument(doc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String query = searchBox.getText();
        String field = (String) fieldBox.getSelectedItem(); // get selected field from combo box
        searchHistory.add(query);
        searchHistoryBox.setText("");
        for (String search : searchHistory) {
            searchHistoryBox.append(search + "\n");
        }
        currentPage = 0; // reset current page to 0
        try {
            Query q = new QueryParser(field, analyzer).parse(query); // use selected field in query parser
            lastQuery = q; // save last query for next page button
            TopDocs docs = searcher.search(q, (currentPage + 1) * 10);
            ScoreDoc[] hits = docs.scoreDocs;
            int start = currentPage * 10;
            int end = Math.min((currentPage + 1) * 10, hits.length);
            resultBox.setText("");
            resultBox.append("Showing results " + (start + 1) + " to " + end + " out of " + hits.length + " total results.\n");
            for (int i = start; i < end; i++) {
                int docId = hits[i].doc;
                Document d = searcher.doc(docId);
                resultBox.append(d.get("artist") + "\t" + d.get("song") + "\t" + d.get("link") + "\t" + d.get("text") + "\n");
            }
        } catch (ParseException | IOException ex) {
            ex.printStackTrace();
        }
    }


}